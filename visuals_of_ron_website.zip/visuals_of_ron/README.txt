VISUALS OF RON — WEBSITE STARTER

HOW TO OPEN
1. Extract the ZIP file.
2. Open the visuals_of_ron folder.
3. Double-click index.html. It should open in your browser.
4. Internet is needed for the sample photos and Google Fonts.

CUSTOMIZE BEFORE PUBLISHING
- Open index.html in Notepad or a code editor.
- Change hello@example.com to your real contact email.
- Replace Instagram and YouTube links with your profile links.
- Replace sample Unsplash image URLs with your own portfolio images.
- Replace the video placeholder with your video embed.

To publish online, you can use GitHub Pages, Netlify, or another static website host.
This starter is a front-end portfolio template; the contact button opens an email app and does not store messages.
